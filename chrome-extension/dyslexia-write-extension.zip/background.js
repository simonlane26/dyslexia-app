// ── Create context menus ───────────────────────────────────────────────────────
function createMenus() {
  chrome.contextMenus.removeAll(() => {
    // Right-click on selected text
    chrome.contextMenus.create({
      id: 'dw-simplify',
      title: 'Simplify with DyslexiaWrite',
      contexts: ['selection'],
    });
    // Right-click anywhere on the page
    chrome.contextMenus.create({
      id: 'dw-simplify-page',
      title: 'Simplify this whole page',
      contexts: ['page'],
    });
    // Right-click anywhere on the page — read aloud, no account needed
    chrome.contextMenus.create({
      id: 'dw-read-page',
      title: 'Read this page aloud',
      contexts: ['page'],
    });
  });
}

chrome.runtime.onInstalled.addListener((details) => {
  createMenus();

  // First install only (not updates) — the extension needs an account to do
  // anything useful, so this is the single biggest drop-off point. Sending
  // people straight to a page that explains that and gets them signed in
  // immediately, rather than leaving them with just a toolbar icon, also
  // lets installs-that-become-signups be measured via utm_source=extension.
  if (details.reason === 'install') {
    chrome.tabs.create({ url: 'https://www.dyslexiawrite.com/welcome?utm_source=extension&utm_medium=install' });
  }
});

// ── Website -> extension handoff ────────────────────────────────────────────
// Lets /extension-connect hand the auth token straight to the extension via
// chrome.runtime.sendMessage instead of the user copying and pasting it.
// Requires manifest.json's externally_connectable to list the site's origin.
chrome.runtime.onMessageExternal.addListener((message, _sender, sendResponse) => {
  if (message?.type === 'DW_PING') {
    sendResponse({ ok: true, installed: true });
    return;
  }
  if (message?.type === 'DW_CONNECT_TOKEN' && typeof message.token === 'string' && message.token) {
    chrome.storage.local.set({ dw_token: message.token }, () => sendResponse({ ok: true }));
    return true; // keep the message channel open for the async sendResponse
  }
  sendResponse({ ok: false, error: 'Unrecognised message' });
});

// ── Helper: ensure content script is injected ──────────────────────────────────
// Returns false if the tab is restricted (chrome://, extension pages, etc.)
async function ensureContentScript(tabId) {
  try {
    await chrome.scripting.executeScript({ target: { tabId }, files: ['content.js'] });
    return true;
  } catch {
    return false; // restricted page — cannot inject
  }
}

function safeSend(tabId, msg) {
  chrome.tabs.sendMessage(tabId, msg).catch(() => {});
}

// ── Context menu handler ───────────────────────────────────────────────────────
chrome.contextMenus.onClicked.addListener(async (info, tab) => {
  if (!tab?.id) return;

  // ── Selection simplify (existing) ─────────────────────────────────────────
  if (info.menuItemId === 'dw-simplify') {
    const text = (info.selectionText || '').trim();
    if (!text) return;

    // Best-effort injection for tabs opened before the extension was installed.
    // The manifest already injects content.js on all URLs, so this may be a no-op.
    await ensureContentScript(tab.id);

    safeSend(tab.id, { type: 'DW_SIMPLIFY_START' });

    const { dw_token } = await chrome.storage.local.get('dw_token');
    if (!dw_token) {
      safeSend(tab.id, { type: 'DW_SIMPLIFY_ERROR', message: 'Connect your account first — open the DyslexiaWrite extension.' });
      return;
    }

    try {
      const res = await fetch('https://www.dyslexiawrite.com/api/simplify', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', 'Authorization': `Bearer ${dw_token}` },
        body: JSON.stringify({ text }),
      });
      const data = await res.json();
      if (!res.ok) {
        safeSend(tab.id, { type: 'DW_SIMPLIFY_ERROR', message: data.message || data.error || 'Something went wrong.' });
        return;
      }
      safeSend(tab.id, { type: 'DW_SIMPLIFY_RESULT', original: text, simplified: data.simplifiedText });
    } catch {
      safeSend(tab.id, { type: 'DW_SIMPLIFY_ERROR', message: 'Could not reach server. Check your connection.' });
    }
  }

  // ── Whole-page simplify (new) ──────────────────────────────────────────────
  if (info.menuItemId === 'dw-simplify-page') {
    await ensureContentScript(tab.id);

    const { dw_token, dw_simplify_level } = await chrome.storage.local.get(['dw_token', 'dw_simplify_level']);
    if (!dw_token) {
      safeSend(tab.id, { type: 'DW_SIMPLIFY_ERROR', message: 'Connect your account first — open the DyslexiaWrite extension.' });
      return;
    }

    safeSend(tab.id, { type: 'DW_SIMPLIFY_PAGE', token: dw_token, level: dw_simplify_level || 2 });
  }

  // ── Whole-page read aloud (new) ────────────────────────────────────────────
  if (info.menuItemId === 'dw-read-page') {
    await ensureContentScript(tab.id);
    const { dw_read_rate } = await chrome.storage.local.get('dw_read_rate');
    safeSend(tab.id, { type: 'DW_READ_PAGE', rate: dw_read_rate || 1 });
  }
});
